ECE 4570 - Spring 2006
----------------------

This pack contains the PocketPC control point for P5.  Copy the contents of this folder (binary + 3 dlls) into a directory on the ipaq and run.
